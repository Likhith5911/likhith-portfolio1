# Likhith D Kunder — Portfolio

Personal portfolio website for Likhith D Kunder, Content Writer & Scriptwriter.

## How to deploy on GitHub Pages

1. Go to your GitHub repo: `likhith5911/likhith-portfolio`
2. Delete all existing files
3. Upload everything from this folder (index.html + README.md)
4. Go to **Settings → Pages → Source → Deploy from branch → main → / (root)**
5. Save — your site will be live at `likhith5911.github.io/likhith-portfolio/` in ~60 seconds

## To update a work sample link

Open `index.html` in any text editor, find the article title, and replace the `href="..."` on the link below it.
